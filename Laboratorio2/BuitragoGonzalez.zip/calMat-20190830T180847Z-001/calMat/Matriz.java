/**
 * @author ECI, 2019
 *Autores:
 *  -Santiago Buitrago
 *  -Cesar Gonzalez
 */
public class Matriz{
    
    public static Matriz UNCERO= new Matriz(new int[][]{{0}});
    
    /**
     * Retorna una matriz dados sus elementos. Si hay error en datos, retorna la matriz [0]
     */
    public Matriz (int  elementos[][]) {

    }
   
    
     /**
     * Retorna una matriz da su diagonal. Si hay error en datos, retorna la matriz [0]
     */    
    public Matriz (int d []){

    }    

    /**
     * Retorna una matriz de un numero repetido dada su dimension. Si hay error en datos, retorna la matriz [0]
     */
    public Matriz (int e, int f, int c) {

    }
    
    /**
     * Retorna una matriz identidad dada su dimension. Si hay error en datos, retorna la matriz [0]
     */
    public Matriz (int n) {
    }
    
    
    public Matriz dimension(){
        return null;
    }
    
    
    public int get(int f, int c){
        return 0;
    }
    
    /**
     * Compara esta matriz con otra
     */
    public boolean equals (Matriz otra) {
        return false;
    }

    /** 
     * Compara esta matriz con otra
     */
    @Override
    public boolean equals(Object otra) {
            return false;
    }
    
    
    /** 
     * Retorna una cadena con los datos de la matriz alineado por columna
     * 
    */
    @Override
    public String toString () {
          String s = "";
          return s;
    }   
    
    //Retorna la matriz con el numero de filas o columnas
    public Matriz sume(Matriz m){
        return null;
    }
    
    //Retorna una matriz de un elemento
    public Matriz sume(){
           return null;
    }    

    //foc: indica si la suma es por filas('f') o por columnas('c')
    public Matriz sume(char foc){
        return null;
    }
    

    

    
 
}
