package aplicacion;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import aplicacion.*;
import java.awt.Color;
/**
 * The test class BodyTicTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class BodyTicTest{       
    @Test 
    public void DeberiaCrearDeportista(){
        Salon abc = Salon.demeSalon();
        Deportista manuel = new DeportistaHablador(abc,"Carlos",100, 100); 
        manuel.inicie();
        assertFalse(manuel.getPosicionY()>100);
    }
    
    @Test 
    public void DeberiaSerGris(){
        Salon abc = Salon.demeSalon();
        Bola pelota = new Bola(abc,100, 100);
        pelota.inicie();
        pelota.pare();
        assertEquals(pelota.getColor(), Color.GRAY);
    }
    
    @Test 
    public void DeberiaCrearDeportistaHablador(){
                
    }
}
