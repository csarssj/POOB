package aplicacion;

public class bodyTIcExcepcion extends Exception{

	public bodyTIcExcepcion(String msg){
		super(msg);
	}
}
