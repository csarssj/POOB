package presentacion;


import javax.swing.*;

import aplicacion.DonkeyPoob;
import resources.*;



import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;

public class DonkeyGUI extends JFrame{
    UnJugador gamePanel; //panel que se usa en frame actual
    DonkeyPoob gameModel; //modo de juego actual que usa este frame
    UnJugador menuPanel; //menu panel 
	private final static int ANCHO = 640;
	private final static int ALTO = 680;
	private JFileChooser fileChooser;
	private JMenu opciones;
	private JMenuBar menu;
	private JMenuItem abrir,guardar,importar2;
	private static JPanel Pmenu,normal;
	
	private DonkeyGUI(){
		
		setResizable(false);
		prepareElementos();
		prepareElementosMenu();
		prepareAcciones();
		
	}
	public DonkeyGUI(DonkeyPoob model, UnJugador panel) throws IOException //constructor
    {
		/*Prepare JFrame*/
		this.setTitle("Donkey Poob");
		this.setSize(ANCHO , ALTO);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		addWindowListener(new FrameListener()); 
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	    this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
	    this.gameModel = model; //get model
	    this.menuPanel = panel; //get panel
	    gamePanel = new UnJugador(model); //crear un panel de juego a partir de un modo de juego
	    gamePanel.setSize(ANCHO,ALTO);
	    this.add(gamePanel); //agregar panel al frame
    }
	public static void main(String[] args) throws IOException, InstantiationException{
		DonkeyGUI gui = new DonkeyGUI();
		/*Prepare JFrame*/
		gui.setTitle("Donkey Poob");
		gui.setSize(ANCHO , ALTO);
		gui.setResizable(false);
		gui.setLocationRelativeTo(null);
		gui.setVisible(true);
	}
	private void prepareElementos(){
		
		Pmenu=new MenuInicio();
		add(Pmenu);
		Pmenu.setVisible(true);
		
		setLocationRelativeTo(null);
		fileChooser = new JFileChooser();
		fileChooser.setVisible(false);
		
	}
	private void prepareElementosMenu() {
		menu= new JMenuBar();
		opciones= new JMenu("Opciones");
		abrir= new JMenuItem("abrir");
		guardar= new JMenuItem("guardar");
		importar2= new JMenuItem("importar");
		opciones.add(abrir);
		opciones.add(guardar);
		opciones.add(importar2);

		menu.add(opciones);
		add(menu, BorderLayout.NORTH);
	}
	public static  void unJugador() {
		normal=new UnJugador();
		normal.setFocusable(true);
		
		normal.setVisible(true);
		//Pmenu.setVisible(true);
		//Pmenu.setFocusable(false);
		
	}
	public static  void abrirMenu1() {
		Pmenu.setVisible(true);
		
	}
	private void prepareAcciones() {
		
		abrir.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				//abrir();
			}
		});
		guardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				//guardar();
			}
		});
		importar2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
			//	importar();
			}
		});
		
	}
	private void accionSalir(){
		int confirmado = JOptionPane.showConfirmDialog(null, "Seguro que deseas salir","Guardar",JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE);
		if (confirmado == 0){
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			System.exit(0);
		}
		else if (confirmado == 1 || confirmado == 2){
			setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		}
	}
	class FrameListener extends WindowAdapter // pregunte si está bien salir
    {
       public void windowClosing(WindowEvent e)
        {
            gameModel.wait = true; //configura gameModel para que no se actualice más: se bloqueará en un bucle hasta que se establezca el parámetro de espera
            int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog(null, "Tu puntaje es: " + gameModel.score + ". ¿Estas seguro de salir?", "Salir", dialogButton);
            if(dialogResult == 0)
            {
                //opción sí, por lo tanto, regrese al menú principal
                gameModel.username = JOptionPane.showInputDialog("Ingresa tu nombre:");
                if (gameModel.username.equals("")) gameModel.username = "desconocido";
                gameModel.gameOver = true; 
                
                setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //cerrar la ventana
            }
            else
            {
                //opcion no, por lo tanto continua 
                gameModel.wait = false; //continua jugando
                setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); //no cierre el frame

            }
        }
    }
    
    public UnJugador getGamePanel() 
    {
        return gamePanel;
    }
		
	
}