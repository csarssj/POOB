package presentacion;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;


import aplicacion.*;


public class UnJugador extends JPanel implements Observer {
	private DonkeyGUI frame;
	public DonkeyPoob logica;
	private InputController inputController = new InputController();
	private ArrayList<Integer> keysDown;
	private Thread hilo;
	private int score = 0;
	private int level = 1;
	private int highScore;
	private DonkeyPoob model;
	boolean pausa=false; 
	
	//Imagenes
	Image mario = new ImageIcon(getClass().getResource("/resources/mario.png")).getImage();
    Image kong = new ImageIcon(getClass().getResource("/resources/konky_dong.gif")).getImage();
    Image peach = new ImageIcon(getClass().getResource("/resources/peach.png")).getImage();
    Image barrel = new ImageIcon(getClass().getResource("/resources/barrel.png")).getImage();
    Image platform = new ImageIcon(getClass().getResource("/resources/platform.png")).getImage();
    Image ladder = new ImageIcon(getClass().getResource("/resources/ladder.png")).getImage();
	
	public UnJugador() {
	     //colores
		 setOpaque(true);
	     this.setBackground(Color.black);
	     Font thisFont = new Font("Arial", Font.PLAIN, 36);
	
	     //usando un diseño de bolsa de rejilla en el panel con restricciones
	     GridBagLayout gblPanel = new GridBagLayout();
	     this.setLayout(gblPanel);
	     GridBagConstraints c = new GridBagConstraints();
	     c.insets = new Insets(0,0,0,0);
	     
	     try
         {
             PlayGame();
         } catch (InterruptedException | IOException ex) {
             Logger.getLogger(UnJugador.class.getName()).log(Level.SEVERE, null, ex);
         }
	}
	public UnJugador(DonkeyPoob model) throws IOException 
    {
        setOpaque(true);
        setBackground(Color.BLACK);
        this.model = model;
        this.model.addObserver(this);
    }	

     class InputController implements KeyListener //clase utilizada para presionar las teclas desde el teclado
     {
     private final boolean[] down = new boolean[255];
     private final boolean[] pressed = new boolean[255];

     @Override
     public void keyPressed(KeyEvent e)
     {
         down[e.getKeyCode()] = true;
         pressed[e.getKeyCode()] = true;
         model.passKeysDownToPlayer(down); //pasar la llave al modelo
     }

     @Override
     public void keyReleased(KeyEvent e)
     {
         down[e.getKeyCode()]= false;
         model.passKeysDownToPlayer(down); //pasar la llave al modelo
     }

     @Override
     public void keyTyped(KeyEvent e)
     {
    	// hacer: todos los métodos deben ser anulados
     }
 
     }
	
	public void PlayGame() throws InterruptedException, IOException
    {
        model = new DonkeyPoob(); //crear nuevo modo de juego
        UnJugador tempPan = this;
        frame = new DonkeyGUI(model, tempPan); //crear el frame del modo de juego
        frame.addKeyListener(inputController);
        
        //hacer un hilo que controle la lógica del modo de juego
        Thread thread = new Thread(){
            @Override
            public void run()
            {	
                try
                {
                    boolean endGame = false;
                    while (!endGame)
                    {
                        if (!model.startGame(frame))
                        {
                            //el juego ha finalizado.
                            frame.dispose();
                            endGame = true;
                        }
                        else
                        {
                            //el jugador quiere volver a jugar, crear un nuevo controlador para las teclas; si no, Mario sigue saltando / corriendo después de que se inicia el nuevo juego
                            frame.dispose();
                            model = new DonkeyPoob();
                            frame = new DonkeyGUI(model, tempPan);
                            inputController = new InputController();
                            frame.addKeyListener(inputController);
                        }
                    }
                } catch (InterruptedException e) {
                } catch (IOException ex) {
                    Logger.getLogger(UnJugador.class.getName()).log(Level.SEVERE, null, ex);
                }    
            }
        };
        thread.start(); //iniciamos el hilo
        AbstractAction FPSTimer = new AbstractAction(){
            @Override
            public void actionPerformed(ActionEvent e){
                frame.gamePanel.repaint(); //volver a pintar el frame				
            }			
        };
        new Timer(15, FPSTimer).start();
    }
	@Override
    public void paintComponent(Graphics g) 
    {
        super.paintComponent(g); 
        g.drawImage(kong, 60, 120, 100, 100, this); //dibujar a  kong
        for (ObjetoEstatico object : model.getSOList()) //pintar cada objeto estatico, escaleras,plataformas y peach
        {
            if(object instanceof Plataforma) g.drawImage(platform,(int)object.getXPos(), (int)object.getYPos(), (int)object.getWidth(), (int)object.getHeight(), null);
            if(object instanceof Escalera) g.drawImage(ladder,(int)object.getXPos(), (int)object.getYPos(), (int)object.getWidth(), (int)object.getHeight(), null);
            if(object instanceof Peach) g.drawImage(peach,(int)object.getXPos(), (int)object.getYPos(), (int)object.getWidth(), (int)object.getHeight(), null);
        }
        
        //dibujar el puntaje arriba de la pantalla
        g.setColor(Color.WHITE);
        g.drawString("Score: " + model.getScore(), 500, 50); 

        for (ObjetoMovimiento object : model.getMOList()) //pintar cada objeto en movimiento, barriles y mario
        {
            if(object instanceof Barril) g.drawImage(barrel,(int)object.getXPos(), (int)object.getYPos(), (int)object.getWidth(), (int)object.getHeight(), null);
            if(object instanceof Mario) g.drawImage(mario, (int)object.getXPos(),(int)object.getYPos(),(int)object.getWidth(),(int)object.getHeight(), null);
        } 	
    }

    public void update(Observable caller, Object data)
    {
        repaint();
    }
}
