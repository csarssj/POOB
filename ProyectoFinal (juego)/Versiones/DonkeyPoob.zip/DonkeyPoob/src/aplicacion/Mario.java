package aplicacion;

import java.util.ArrayList;

/**
 * Clase Mario rescatador de la princesa de las manos de DonkeyKong
 * @author Cesar Gonzalez y Brayan Buitrago
 * @version 15/11/2019
 */
public class Mario extends ObjetoMovimiento {
   
    //constantes
    private final float jumpHeight = 3.6f; //altura que mario salta
    
    //booleanos que nos dicen que teclas fueron presionadas
    private boolean goLeft;
    private boolean goRight;
    private boolean goUp;
    private boolean goDown;
    private boolean jump; //espacio fue presionado 
    
    private boolean keysDown[] = new boolean[255]; //Array de booleanos que nos dice qué tecla se presiona
    public boolean jumping; //si Mario está saltando o no
    private boolean hasWon = false; //si se gano, falso por defecto
    
    /**
     * Constructor de mario
     * @param x posicion en coordenada x
     * @param y posicion en coordenada y
     * @param h alto del objeto
     * @param w ancho del objeto
     * @param SOList lista objeto estatico
     */
    public Mario(int x, int y, int h, int w, ArrayList<ObjetoEstatico> SOList) 
    {
        super(x, y, h, w, SOList);
        xVel = 5f;
        yVel = 5f;
    }
    
    /**
     * Coloca todos los parametros de mario por default
     */
    public void setToDefault() 
    {
        this.goLeft = false;
        this.goRight = false;
        this.goUp = false;
        this.goDown = false;
        this.jump = false;
        for (int i = 0; i < 255;i++) this.keysDown[i] = false; 
        this.jumping = false;
        this.hasWon = false;
    }

    @Override
    public void act(int time)
    {
        //inicializar cambios

        dx = 0;
        dy = 0;

        //llama a la función  super act para la gravedad y pararse en la plataforma
        super.act(time);
        readInput();
        if(jump && !jumping && standing()) jumping = true; //empieza a saltar
        if (standing() || collidingWithLadder == null) isClimbing = false;  //no suba a menos que colisione con la escalera
        if((collidingWithLadder != null)) isClimbing = true; //Si Mario está colisionando con la escalera, es verdadero
        dx += (goRight ? xVel : 0) - (goLeft ? xVel : 0); //cambiar el delta x
        if (isClimbing) dy += (goDown ? yVel : 0) - (goUp ? yVel : 0); //si Mario está subiendo, cambie delta y
        if(jumping) dy += -jumpHeight; //Si Mario está saltando, cambie la coordenada y
        xPos += dx; 
        yPos += dy;
        if (collidingWithLadder != null && !standing()) xPos -= dx; //desactivar la caída de la escalera
        if (checkSOCollisions(SOList)) // hubo una colisión
        {
            if (collidingWithPeach) hasWon = true; //si Mario ha alcanzado a peach, el juego ha terminado
            if (collidingWithLadder == null) yPos -= dy; //deshabilite el movimiento si el movimiento en y resultaría en una colisión
        }
        if (this.xPos >= 230 && this.xPos <=270 && this.yPos <= 130 && this.yPos >= 90) hasWon = true; //compruebe si no está cerca de peach, para que no tenga que estar exactamente en la misma posición, peach está en 250, 105
    }
    
    /**
     * Lectura de las teclas
     */
    public void readInput()
    {
        goLeft = keysDown[37]; 
        goRight = keysDown[39]; 
        goUp = keysDown[38];
        goDown = keysDown[40]; 
        jump = keysDown[32]; 
    }

    /**
     * Ingresan las teclas presionadas del modo de juego.
     * @param down arreglo de booleanos que nos dice que tecla fue presionada
     */
    public void setKeysDown(boolean[] down) 
    {
        keysDown = down;
    }
    
    //funciones que retornan parametros
    
    @Override
    public boolean left() 
    {
        return goLeft;
    }

    @Override
    public boolean right() 
    {
        return goRight;
    }

    @Override
    public boolean up() 
    {
        return goUp;
    }

    @Override
    public boolean down() 
    {
        return goDown;
    }

    public void setJump(boolean b)
    {
        jumping = b;
    }
    
    public boolean hasWon()
    {
        return hasWon;
    }

}

