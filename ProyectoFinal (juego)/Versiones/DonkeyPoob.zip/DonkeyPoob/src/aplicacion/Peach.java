package aplicacion;

/**
 * Clase princesa la cual mario busca rescatar
 * @author Cesar Gonzalez y Brayan Buitrago
 * @version 15/11/2019
 */
public class Peach extends ObjetoEstatico {
	/**
	 * Constructor para la clase princesa
     * @param x posicion en coordenada x
     * @param y posicion en coordenada y
     * @param h alto del objeto
     * @param w ancho del objeto
	 */
    public Peach(int x, int y, int h, int w)
    {
        super(x, y, h, w);
    }
    
}
