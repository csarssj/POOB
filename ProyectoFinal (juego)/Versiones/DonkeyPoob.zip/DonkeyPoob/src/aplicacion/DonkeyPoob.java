package aplicacion;

import presentacion.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;
import javax.swing.JOptionPane;

/**
 * Clase DonkeyPoob ejecuta el juego, prepara todos los elementos y ejecuta la parte logica.
 * @author: Cesar Gonzalez y Brayan Buitrago
 * @version: 15/11/2019
*/
public final class DonkeyPoob extends Observable {
    
    //constantes
    final int SCREEN_X = 640; //ancho de la pantalla
    final int SCREEN_Y = 680; //alto de la pantalla
    final int platform_HEIGHT = 20; //alto de la plataforma
    final int platform_WIDTH = 30; //ancho de la plataforma
    final private int gravityTime = 10; //manejar la gravedad cada 10 milisegundos
    final private int barrelSpawnTime = 150; //barilles aparecen cada 150 milisegundos
    
    public boolean wait = false; //si este modelo debe pausarse
    public String username; //nombre de usuario que se preguntará al final del juego
    public int score; //puntaje actual
    public boolean gameOver; //true si el juego termina
    private ArrayList<ObjetoEstatico> SOList; //todos los ojetos estaticos
    public ArrayList<ObjetoMovimiento> MOList; //todos los objetos en movimiento
    private int timer = 0; //tiempo actual, comienza en 0

    private int epochs; //una variable utilizada solo para iterar y finalizar el juego si lleva demasiado tiempo
    public ArrayList<Integer> gravityTimes; //tiempo de gravedad para cada objeto en movimiento: cada objeto con índice i en MO tiene el tiempo de gravedad en esta lista en el índice i
    private Mario mario; //jugador
    private Peach peach; //princesa
    
    
    public DonkeyPoob() 
    {
        initGame();	
    }
    
    public boolean startGame(DonkeyGUI frame) throws InterruptedException, IOException
    {
        while(epochs < 10000) //después de que epochs sea 10000, el juego terminará
        {
            while (wait == true) //bucle para JFrame: cuando la espera es verdadera, el juego está "en pausa"
            {
                Thread.sleep(1);
            }
            epochs++;
            timer++;   
            if(timer % gravityTime == 0) incrementTime(); //manejar la gravedad cada 10 milisegundos
            if(timer % barrelSpawnTime == 0) spawnBarrel(); //generar un barril cada 150 milisegundos      
            if(timer > 1500) timer = 0; //restablecer el temporizador eventualmente, para evitar el overflow
            for(int i = 0; i < MOList.size(); i++)
            {
                //hacer que todos los objetos en movimiento actúen / se muevan
                MOList.get(i).act(gravityTimes.get(i));
                if(mario.hasWon()) //mario ha ganado
                {
                    if (!continueAfterWin()) return false;
                }
                if(mario.checkMOCollision(MOList)) //Mario es golpeado por un barril
                {
                    //mario murio
                    endLostGame(); //funcion para saber si perdio
                    if (gameOver) //el jugador ha elegido no volver a jugar
                    {
                        frame.dispose(); //cerrar el marco -> volver al menú principal
                        return false; //declaraciones de retorno para la función menuPanel
                    }
                    else return true;
                }
                else if(MOList.get(i).getYPos() >= SCREEN_Y) //eliminar objeto si está fuera de la pantalla
                {
                    if (mario.equals(MOList.get(i))) //Mario se salió de la pantalla
                    { //juego perdido
                        endLostGame(); //función de juego perdido
                        if (gameOver) //el jugador ha elegido no volver a jugar
                        {
                        	frame.dispose(); //cerrar el marco -> volver al menú principal
                            return false; //declaraciones de retorno para la función menuPane
                        }
                        else return true;
                    }
                    else
                    {
                        //el objeto que cae de la pantalla es un barril, por lo tanto, retire el barril y es el tiempo de gravedad fuera de la pantalla
                        MOList.remove(i);
                        gravityTimes.remove(i);
                    }
                }
                //aumentar la puntuación al saltar sobre el barril
                else checkForPoints(MOList.get(i));
            }
            UnJugador tempPanel = frame.getGamePanel(); //obtener el panel del frame
            tempPanel.repaint(); //repaint el panel
            frame.add(tempPanel); //mostrar el panel en el frame
            Thread.sleep(15);
        }
        return true;
    }
    
    private void checkForPoints(ObjetoMovimiento tempMov) //verifica si Mario está saltando sobre un barril y si agrega puntos
    {
        if(tempMov.getYPos() >= mario.getYPos() && tempMov.getYPos() <= mario.getYPos() + 100 && 
            mario.getXPos() >= tempMov.getXPos()	&&
            mario.getXPos() <= tempMov.getXPos()+tempMov.getWidth() &&
            !(tempMov.pointAwarded) && mario.jumping && !mario.equals(tempMov))
        {
            tempMov.setPointAwarded();
            score += 100;
        }
    }
 
    private boolean continueAfterWin() throws InterruptedException //qué hacer después de que el jugador haya ganado
    {
        score+=1000; //suma puntos por ganar el juego
        JOptionPane.showMessageDialog(null, "Ganaste! Tu puntaje es:" + score);
        this.username = JOptionPane.showInputDialog("Ingresa tu nombre:");
        if (username.equals("")) username = "desconocido";
        gameOver = true;
        Thread.sleep(50); //espera un momento
        return false;
    }
    
    private void endLostGame() throws InterruptedException //qué hacer después de que el jugador haya perdido
    {
        //mario murio
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(null, "Tu puntaje es: " + score + ". ¿Quieres intentarlo de nuevo?", "Game over", dialogButton);
        if(dialogResult == 0)
        {
            //sí, por lo tanto, inicie nuevamente y comience nuevamente
            MOList.clear();
            gravityTimes.clear();
            score = 0;
            initGame();
            Thread.sleep(30);
        }
        else
        {
            //no , entones termine y guarde el puntaje
            this.username = JOptionPane.showInputDialog("Ingresa tu nombre:");
            if (username.equals("")) username = "desconocido";
            gameOver = true;  
            Thread.sleep(50);
        }
    }
    
    public void initGame() //inicializa el comienzo del juego
    {
        initStaticObjects();
        initMovingObjects();
        timer = 0;
        gameOver = false;
        mario.setToDefault();
    }

    private void initStaticObjects() //inicialice todos los objetos estáticos: agrega objetos estáticos a SOList
    {
        //inicializar lista
        SOList = new ArrayList<>();

        //crear plataformas	

        //creamos las plataformas
        for(int i = 0; i < SCREEN_X/2; i = i + platform_WIDTH)
        {
            SOList.add(new Plataforma(50 + i,SCREEN_Y - 50, platform_HEIGHT, platform_WIDTH));
        }

        int y = SCREEN_Y - 50;
        for(int i = SCREEN_X/2; i < SCREEN_X - 50; i = i + platform_WIDTH)
        {
            SOList.add(new Plataforma(i,y,platform_HEIGHT,platform_WIDTH));
            y = y - 1;
        }

        int x = SCREEN_X - 100;
        y = SCREEN_Y - 150;
        for(int i = x - 20; i > 35; i = i - platform_WIDTH)
        {
            SOList.add(new Plataforma(i,y,platform_HEIGHT,platform_WIDTH));
            y = y - 1;
        }


        y = SCREEN_Y - 300;
        for(int i = 100; i < SCREEN_X - 50; i = i + platform_WIDTH)
        {
            SOList.add(new Plataforma(i,y,platform_HEIGHT,platform_WIDTH));
            y = y - 1;
        }

     
        x = SCREEN_X - 100;
        y = SCREEN_Y - 450;
        for(int i = x - 20; i > 50; i = i - 30)
        {
            SOList.add(new Plataforma(i,y,20,30));
            y = y - 1;
        }
        
        //donde va a estar peach
        x = 230;
        y = 140;
        SOList.add(new Plataforma(x, y, 20, 30));
        for (int i = x; i < x + 180; i = i + 30)
        {
            SOList.add(new Plataforma(i, y, 20, 30));
        }

        //crear Escaleras
        

        for(int i = 0; i < 9*10; i += 10)
        {
            SOList.add(new Escalera(500,612-i,10,15));
        }
        

        for(int i = 0; i < 12*10; i += 10)
        {
            SOList.add(new Escalera(120,510-i,10,15));
        }
        

        for(int i = 0; i < 12*10; i += 10)
        {
            SOList.add(new Escalera(200,505-i,10,15));
        }
        

        for(int i = 0; i < 12*10; i += 10)
        {
            SOList.add(new Escalera(510,360-i,10,15));
        }

        for(int i = 0; i < 6*10; i += 10)
        {
            SOList.add(new Escalera(320,210-i,10,15));
        }
        

        for(int i = 0; i < 11*10; i += 10)
        {
            SOList.add(new Escalera(180,210-i,10,15));
        }
        

        for(int i = 0; i < 11*10; i += 10)
        {
            SOList.add(new Escalera(220,210-i,10,15));
        }
        
        //creamos a peach
        peach = new Peach(250,105,35,20);
        SOList.add(peach);
    }

    private void initMovingObjects() //inicializar todos los objetos en movimiento: agregar objetos en movimiento a MOList
    {   
        //inicializar lista
        MOList = new ArrayList<>();
        
        mario = new Mario(60,600,35,20, SOList);
        MOList.add(mario);
        
        //Inicializar los temporizadores de gravedad de los objetos en movimiento.
        gravityTimes = new ArrayList<>();
        for (int i = 0; i < MOList.size(); i++)
        {
            gravityTimes.add(0);
        }
    }
    
    public void spawnBarrel() //agrega un nuevo barril al juego cada 150 milisegundos, el lugar de generación está al lado de Kong
    {
        gravityTimes.add(0);
        MOList.add(new Barril(120,200,20,25, SOList, true));
    }
    
    public void incrementTime() //incrementa los tiempos de gravedad para mover objetos desde MOList
    {
        for(int i = 0; i < MOList.size(); i++)
        {
            ObjetoMovimiento MO = MOList.get(i);
            if(MO.standing())
            {
                gravityTimes.set(i, 0);
                if(MO instanceof Mario) //Si el objeto es Mario y está parado, salta a falso
                {
                    ((Mario) MOList.get(i)).setJump(false);
                }			
            }
            else
            {
                gravityTimes.set(i, (gravityTimes.get(i)) + 1) ;
            }		
        }	
    }
    
    public void passKeysDownToPlayer(boolean[] down) //función utilizada para presionar teclas en el teclado, utilizada en menuPanel
    {
        mario.setKeysDown(down);
    }
    
    //funciones de retorno para elementos en la clase

    public ArrayList<ObjetoEstatico> getSOList()
    {
        return SOList;
    }

    public ArrayList<ObjetoMovimiento> getMOList()
    {
        return MOList;
    }

    public boolean isGameOver()
    {
        return gameOver;
    }
    public int getScore()
    {
        return score;
    }
	    
}   

